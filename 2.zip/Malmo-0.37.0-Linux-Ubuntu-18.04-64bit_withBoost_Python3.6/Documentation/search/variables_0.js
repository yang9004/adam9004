var searchData=
[
  ['channels',['channels',['../structmalmo_1_1_timestamped_video_frame.html#a0d84d5f94e6a1dacc25c1c99c28af0fc',1,'malmo::TimestampedVideoFrame']]],
  ['clients',['clients',['../structmalmo_1_1_client_pool.html#aee937a22685ef66dfab6a4a65d56166f',1,'malmo::ClientPool']]],
  ['command_5fport',['command_port',['../structmalmo_1_1_client_info.html#a15c9e73271b955e629055d67bea6dcd4',1,'malmo::ClientInfo']]],
  ['control_5fport',['control_port',['../structmalmo_1_1_client_info.html#ac3389ee74d259c2cf703377a5f33071b',1,'malmo::ClientInfo']]]
];
