var searchData=
[
  ['xpos',['xPos',['../structmalmo_1_1_timestamped_video_frame.html#a658a8b3d24d3f424dca6699e65eb7961',1,'malmo::TimestampedVideoFrame']]]
];
