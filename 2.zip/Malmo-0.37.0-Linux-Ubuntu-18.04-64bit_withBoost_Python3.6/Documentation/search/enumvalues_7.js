var searchData=
[
  ['video',['VIDEO',['../structmalmo_1_1_timestamped_video_frame.html#a6016177a24884e003e9696bcfcf172a2ac48bf8ddfa9c219fda933d0b61745f1a',1,'malmo::TimestampedVideoFrame']]]
];
