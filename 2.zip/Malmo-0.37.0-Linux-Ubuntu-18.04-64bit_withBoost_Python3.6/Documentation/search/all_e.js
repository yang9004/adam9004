var searchData=
[
  ['raw_5fbmp',['RAW_BMP',['../structmalmo_1_1_timestamped_video_frame.html#a72f071afb831b7e2036255229d676515a5f4970c37a69c2cf417ef07a7feaaef8',1,'malmo::TimestampedVideoFrame']]],
  ['receivedargument',['receivedArgument',['../classmalmo_1_1_argument_parser.html#ad38a7e8b64676d4e1dc79ce781eb2d59',1,'malmo::ArgumentParser']]],
  ['recordbitmaps',['recordBitmaps',['../structmalmo_1_1_mission_record_spec.html#ac538c44a9cfe0a85cd8c10d42099adcf',1,'malmo::MissionRecordSpec']]],
  ['recordcommands',['recordCommands',['../structmalmo_1_1_mission_record_spec.html#ac7684f3b5371111753af55c472c7e986',1,'malmo::MissionRecordSpec']]],
  ['recordmp4',['recordMP4',['../structmalmo_1_1_mission_record_spec.html#abb9a25b0709327867295d2ce21d8b086',1,'malmo::MissionRecordSpec::recordMP4(int frames_per_second, int64_t bit_rate)'],['../structmalmo_1_1_mission_record_spec.html#a0d9c69da74640e54376ca872ef2ad5bd',1,'malmo::MissionRecordSpec::recordMP4(TimestampedVideoFrame::FrameType type, int frames_per_second, int64_t bit_rate, bool drop_input_frames)']]],
  ['recordobservations',['recordObservations',['../structmalmo_1_1_mission_record_spec.html#a3f82e253a82193f6c6660a5a04860aad',1,'malmo::MissionRecordSpec']]],
  ['recordrewards',['recordRewards',['../structmalmo_1_1_mission_record_spec.html#a953c319a7804ce31e05978916083fb4b',1,'malmo::MissionRecordSpec']]],
  ['removeallcommandhandlers',['removeAllCommandHandlers',['../classmalmo_1_1_mission_spec.html#a762ef8e01f258a0f5be76acfc2ae7999',1,'malmo::MissionSpec']]],
  ['request32bppdepth',['request32bppDepth',['../classmalmo_1_1_mission_spec.html#aa083c3406eddddfdd6324d803e67ed09',1,'malmo::MissionSpec']]],
  ['requestcolourmap',['requestColourMap',['../classmalmo_1_1_mission_spec.html#a9ade620ab9f652d4b12b1bccb6f601c8',1,'malmo::MissionSpec']]],
  ['requestluminance',['requestLuminance',['../classmalmo_1_1_mission_spec.html#a32ec928bc789cf1f5d5ea2ecc8f85d6e',1,'malmo::MissionSpec']]],
  ['requestvideo',['requestVideo',['../classmalmo_1_1_mission_spec.html#a681138f45802358f6e7c6a3e9b20390c',1,'malmo::MissionSpec']]],
  ['requestvideowithdepth',['requestVideoWithDepth',['../classmalmo_1_1_mission_spec.html#a7859965bf8aa07246291ecdf16add7bd',1,'malmo::MissionSpec']]],
  ['reverse_5fscanline',['REVERSE_SCANLINE',['../structmalmo_1_1_timestamped_video_frame.html#a72f071afb831b7e2036255229d676515a814dd49d492ea1aba42588c517e73ad3',1,'malmo::TimestampedVideoFrame']]],
  ['rewardforreachingposition',['rewardForReachingPosition',['../classmalmo_1_1_mission_spec.html#ab23cce86d11026aaa40a49f0115d4ad9',1,'malmo::MissionSpec']]],
  ['rewards',['rewards',['../structmalmo_1_1_world_state.html#a44acde3fb3d195fbacb211a7d1aa9b02',1,'malmo::WorldState']]],
  ['rewardspolicy',['RewardsPolicy',['../classmalmo_1_1_agent_host.html#a2479a59c823bb1e9288c94b1a6295663',1,'malmo::AgentHost']]],
  ['rewardxml',['RewardXML',['../classmalmo_1_1_reward_x_m_l.html',1,'malmo']]]
];
