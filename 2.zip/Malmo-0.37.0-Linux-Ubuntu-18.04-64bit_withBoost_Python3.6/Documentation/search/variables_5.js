var searchData=
[
  ['ip_5faddress',['ip_address',['../structmalmo_1_1_client_info.html#ac60d2ad0191ee2a4cbf8cdedd63af6dd',1,'malmo::ClientInfo']]],
  ['is_5fmission_5frunning',['is_mission_running',['../structmalmo_1_1_world_state.html#a144adc14861cd5ae4e755163b321d289',1,'malmo::WorldState']]]
];
