var searchData=
[
  ['clientagentconnection',['ClientAgentConnection',['../structmalmo_1_1_mission_init_x_m_l_1_1_client_agent_connection.html',1,'malmo::MissionInitXML']]],
  ['clientinfo',['ClientInfo',['../structmalmo_1_1_client_info.html',1,'malmo']]],
  ['clientpool',['ClientPool',['../structmalmo_1_1_client_pool.html',1,'malmo']]]
];
