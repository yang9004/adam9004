var searchData=
[
  ['loggingcomponent',['LoggingComponent',['../classmalmo_1_1_logger.html#a3dd9629c1f7260cd64e3925fb13eea90',1,'malmo::Logger']]],
  ['loggingseveritylevel',['LoggingSeverityLevel',['../classmalmo_1_1_logger.html#a3e1f4546121d7847f51b22d6be701a38',1,'malmo::Logger']]]
];
