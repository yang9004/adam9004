var searchData=
[
  ['transform',['Transform',['../structmalmo_1_1_timestamped_video_frame.html#a72f071afb831b7e2036255229d676515',1,'malmo::TimestampedVideoFrame']]]
];
